package shujujjiegou.LinkedList;

public class CircleLinkedList extends SingleLinkedList
{
    private HeroNode current = new HeroNode(0, "", "");
    private HeroNode first = new HeroNode(0, "", "");
}
